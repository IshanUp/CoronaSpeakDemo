<!DOCTYPE html>
<html>
<head>
		<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css">
		<script src="js/jquery.min.js"></script>
		<script type="text/javascript" src="DataTables/datatables.min.js"></script>
		<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
		<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">


	<script>
		$(document).ready(function() {
    	$('#nixviolate').DataTable( {
        "processing": true,
        "serverSide": true,
        "ajax": "getdata.php"
		    } );
		} );

	</script>

	<title>Fetch Data Tables</title>

</head>


<body>

	<table id="nixviolate" class="display" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Company</th>
                <th>Agency</th>
                <th>City</th>
                <th>Parent Company</th>
                <th>Primary Offense</th>
                <th>Penalty Year</th>
                <th>Penalty Amount</th>
            </tr>
        </thead>
        <tbody>
        	
        </tbody>
        <tfoot>
            <tr>
                <th>ID</th>
                <th>Company</th>
                <th>Agency</th>
                <th>City</th>
                <th>Parent Company</th>
                <th>Primary Offense</th>
                <th>Penalty Year</th>
                <th>Penalty Amount</th>
            </tr>
        </tfoot>
    </table>


</body>



</html>